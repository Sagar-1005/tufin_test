We can run this code by running "bash run_docker.sh"
